<html>
    <head>
        <title>Welcome to the admin page!</title>
    </head>
    <body>
        <form method="post" action="insert.php">
            Start Time <input type="text" name="time" />
            Location <input type="text" name="location" />
            Event Name <input type="text" name="event" />
            Event Creator <input type="text" name = "admin" />
            Location Type <input type="text" name="type" />
            <input type="submit" value="submit" />
        </form>
        <?php
            $con = mysql_connect("localhost", "awkwardt", "Gx61JXuJpaU@");
            if (!$con)
                die('Could not connect: ' . mysq_error());

            mysql_select_db("awkwardt_schema", $con);
    
            $result = mysql_query("SELECT * FROM Events");

            echo "<table>";

            while ($row = mysql_fetch_array($result))
            {   
                echo "<tr>";
                echo "<td>" . $row['Time_Held'] . "</td>" . "<td>" . $row['Location'] . "</td>";
                echo "</tr>";
            }   
            echo "</table>";
        ?>
    </body>
</html>
