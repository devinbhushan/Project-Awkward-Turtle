//Progress bar
<div class="progress progress-danger
     progress-striped active">
  <div class="bar"
       style="width: 40%;"></div>
</div>

//bad alert
<div class="alert alert-error">
  ...
</div>

//good alert
<div class="alert alert-success">
  ...
</div>

//Sign in part, use .form-horizontal
<form class="well form-inline">
  <input type="text" class="input-small" placeholder="Email">
  <input type="password" class="input-small" placeholder="Password">
  <button type="submit" class="btn">Go</button>
</form>

//LOOK AT CONTROL GROUP SUBCLASSES to see what those can do

//Use &larr and &rarr on the left and right, respectively, to align things to the left/right

//The thumbnails section has a nice segment on how to do a picture with a caption, inspect element on that

//To close...
<a class="close">&times;</a>

//popovers
<a ... rel="popover" data-content="And here's some amazing content. It's very engaging. right?" data-original-title="A Title"...>..</a>

//Inspect element on typeahead to see what the hell is going on there.
