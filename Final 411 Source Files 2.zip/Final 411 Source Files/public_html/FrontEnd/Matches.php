<?php
  include("../../../validate.php");
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/basic.css" />
<title>See Your Matches</title>
</head>

<body>
<div class="bigdiv">

<?php
  include("profNavbar.php");
?>

<div class="secondary">
<img class="logo" src="../../Images/Turtle.gif"></img>
<ul class="nav nav-list">
  <li class="nav-header">
    Profiles Navigation
  </li>
  <li>
    <a href="../../Profiles.html"><img class="otherpics" src="../../img/otherpics_black/user_black.png"></i>Your Profile</a>
  </li>
  <li>
    <a href='Editprofile.html'><img class="otherpics" src="../../img/otherpics_black/settings_black.png"></img>Edit it</a>
  </li>
  <li class="nav-header">
    Notifications
  </li>
  <li class="active">
    <a href='Matches.html'><img class="otherpics" src="../../img/otherpics_white/user_add_white.png"></img>Matches</a>
  </li>
  <li>
    <a href='Messages.html'><img class="otherpics" src="../../img/otherpics_black/chat_black.png"></img>Messages</a>
  </li>
</ul>
</div>

</div>
</body>
</html>
