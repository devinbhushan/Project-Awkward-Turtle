<div class="navbar navbar-fixed-top">
  	<div class="navbar-inner">
   	 	<div class="container">
        <a class="brand" href="#">
  				Awkward Turtle
			  </a>
      		<ul class="nav">
          </ul>
       </div>
  	</div>
</div>