<div class="navbar navbar-fixed-top">
  	<div class="navbar-inner">
   	 	<div class="container">
        <a class="brand" href="/FrontEnd/HomePage.html">
  				Awkward Turtle
			  </a>
      		<ul class="nav">
  	 			<li>
       			<a href="/FrontEnd/HomePage.php"></i>Home</a>
      		</li>
    			<li class="active">
    				<a href="/FrontEnd/Subpages/Locationspages/Checkin.php" class="">Locations</a>
          </li>
	  			<li>
	  				<a href="/FrontEnd/Profiles.php" class="">Profile</a>
	  			</li>
          <li>
            <a href="/FrontEnd/Subpages/Profilespages/Matches.php">Matches</a>
          </li> 
            <li>
              <a href="/FrontEnd/contactUs.php">Contact Us</a>
            </li>
            <li>
              <a href="/signout.php">Sign Out</a>
            </li>
       </div>
  	</div>
</div>