<div class="secondary">
<img class="logo" src="../../Images/Turtle.gif"></img>
<ul class="nav nav-list">
  <li class="nav-header">
    Locations Navigation
  </li>
  <li>
    <a id="checkSel" href="Checkin.html"><img class="otherpics" src="../../img/otherpics_black/map_marker_black.png"></img>Check-in Somewhere</a>
  </li>
  <li>
    <a id="browseSel" href='Browselocations.html'><img class="otherpics" src="../../img/otherpics_black/search_black.png"></img>Browse Locations</a>
  </li>
  <!--<li>
    <a href='Map.html'><img class="otherpics" src="../../img/otherpics_white/compass_white.png"></img>See the Map</a>
  </li>-->
</ul>
</div>