<?php
  session_start();
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/basic.css" />
<title>Sign Up</title>

 
</head>

<body>
<div class="bigdiv">

<script type="text/javascript" src="jQuery/jquery-1.7.1.js"></script>


<?php
  include("../../signupNavbar.php");
?>

<div class= "origSignup">
<!--<form action="../../../registration.php" method="post">-->

<div class="progress progress-danger progress-striped active">
  <div class="bar" style="width: 100%;"></div></div>

 <?php
   include 'pic.php';
 ?>

<!--<div class="signup-btn">
  <form method="link" action="../Signuppages/Priorities.html">
    <input type="submit" value = "Go Back" class="btn btn-small btn-primary">
  </form>
</div>-->

<!--</form>-->
</div>
</div>
</body>
