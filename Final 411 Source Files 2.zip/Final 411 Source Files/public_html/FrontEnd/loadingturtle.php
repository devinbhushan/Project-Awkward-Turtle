<html>
<head>
<link rel="stylesheet" type="text/css" href="css/basic.css" />
<title>Home Page</title>
</head>

<body>
<div class = "bigassdiv">

<div class = "loadingturtle">
	<img src = "Images/Turtle-Gif.gif"></img>
</div>

</div>
</body>
