-- MySQL dump 10.11
--
-- Host: localhost    Database: awkwardt_schema
-- ------------------------------------------------------
-- Server version	5.0.95-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Events`
--

DROP TABLE IF EXISTS `Events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Events` (
  `Time_Held` varchar(20) NOT NULL default '',
  `Location` varchar(20) default NULL,
  `Event_Name` varchar(20) default NULL,
  `Event_Creator` varchar(20) NOT NULL default '',
  `Location_Name` varchar(20) default NULL,
  PRIMARY KEY  (`Event_Creator`,`Time_Held`),
  KEY `Location` (`Location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Events`
--

LOCK TABLES `Events` WRITE;
/*!40000 ALTER TABLE `Events` DISABLE KEYS */;
INSERT INTO `Events` (`Time_Held`, `Location`, `Event_Name`, `Event_Creator`, `Location_Name`) VALUES ('3:20 PM','Siebel Center','Presentation','Swagasaurus Rex','University Building'),('','','','',''),('6:00 PM','First and Green','Sleep','Devin','Home');
/*!40000 ALTER TABLE `Events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Location`
--

DROP TABLE IF EXISTS `Location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Location` (
  `Address` varchar(20) default NULL,
  `Type_of_Place` varchar(20) default NULL,
  `Average_Per_Night` int(20) default NULL,
  `Crowd_Size` int(20) default NULL,
  `Name_of_Location` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`Name_of_Location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Location`
--

LOCK TABLES `Location` WRITE;
/*!40000 ALTER TABLE `Location` DISABLE KEYS */;
INSERT INTO `Location` (`Address`, `Type_of_Place`, `Average_Per_Night`, `Crowd_Size`, `Name_of_Location`) VALUES ('618 E. Daniel St.','Bar',NULL,NULL,'Kams');
/*!40000 ALTER TABLE `Location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Messaging`
--

DROP TABLE IF EXISTS `Messaging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Messaging` (
  `ID` int(11) NOT NULL auto_increment,
  `sender` varchar(50) default NULL,
  `recipient` varchar(50) default NULL,
  `subject` varchar(50) default NULL,
  `sent` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `message` longtext,
  PRIMARY KEY  (`ID`),
  KEY `sender` (`sender`),
  KEY `recipient` (`recipient`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Messaging`
--

LOCK TABLES `Messaging` WRITE;
/*!40000 ALTER TABLE `Messaging` DISABLE KEYS */;
/*!40000 ALTER TABLE `Messaging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Profile`
--

DROP TABLE IF EXISTS `Profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Profile` (
  `Interest_Level` varchar(20) default NULL,
  `Name` varchar(20) default NULL,
  `Interests` varchar(20) default NULL,
  `Password` varchar(20) default NULL,
  `Favorite_Location` varchar(20) default NULL,
  `Profile_Username` varchar(20) NOT NULL default '',
  `Name_of_Location` varchar(20) default NULL,
  `Admin_of_Event` varchar(20) default NULL,
  PRIMARY KEY  (`Profile_Username`),
  KEY `Favorite_Location` (`Favorite_Location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Profile`
--

LOCK TABLES `Profile` WRITE;
/*!40000 ALTER TABLE `Profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `Profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rankings`
--

DROP TABLE IF EXISTS `Rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rankings` (
  `email` varchar(30) NOT NULL default '',
  `HomeTownPri` int(11) default NULL,
  `MoviePri` int(11) default NULL,
  `MusicPri` int(11) default NULL,
  `SportPri` int(11) default NULL,
  `MajorPri` int(11) default NULL,
  `HobbyPri` int(11) default NULL,
  `BookPri` int(11) default NULL,
  PRIMARY KEY  (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rankings`
--

LOCK TABLES `Rankings` WRITE;
/*!40000 ALTER TABLE `Rankings` DISABLE KEYS */;
INSERT INTO `Rankings` (`email`, `HomeTownPri`, `MoviePri`, `MusicPri`, `SportPri`, `MajorPri`, `HobbyPri`, `BookPri`) VALUES ('jbailey2010@gmail.com',9,8,7,5,8,8,2),('test@gmail.com',9,8,7,5,8,8,2),('jperlin18@gmail.com',6,3,7,5,8,8,1),('Mrs.Android@gmail.com',10,10,10,10,10,10,10),('Android@gmail.com',8,8,2,10,8,8,2),('deck1@illinois.edu',1,9,5,1,3,9,7),('walter18@illinois.edu',2,4,2,5,3,3,3),('zerlure@gmail.com',9,8,8,7,6,9,9),('bhushan1@illinois.edu',4,4,3,4,1,4,7),('perlin1@illinois.edu',7,7,7,7,1,7,7);
/*!40000 ALTER TABLE `Rankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERS`
--

DROP TABLE IF EXISTS `USERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USERS` (
  `email` varchar(50) NOT NULL default '',
  `password` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `bMonth` varchar(20) default NULL,
  `bDay` int(11) default NULL,
  `bYear` int(11) default NULL,
  `HomeState` varchar(255) default NULL,
  `HomeCity` varchar(255) default NULL,
  `Movies1` varchar(255) default NULL,
  `Movies2` varchar(255) default NULL,
  `Movies3` varchar(255) default NULL,
  `Music1` varchar(255) default NULL,
  `Music2` varchar(255) default NULL,
  `Music3` varchar(255) default NULL,
  `Sports1` varchar(255) default NULL,
  `Sports2` varchar(255) default NULL,
  `Sports3` varchar(255) default NULL,
  `Major` varchar(255) default NULL,
  `MajorSchool` varchar(255) default NULL,
  `Hobbies1` varchar(255) default NULL,
  `Hobbies2` varchar(255) default NULL,
  `Hobbies3` varchar(255) default NULL,
  `Book1` varchar(255) default NULL,
  `Book2` varchar(255) default NULL,
  `Book3` varchar(255) default NULL,
  `gender` varchar(50) default NULL,
  `pic_url` varchar(50) default NULL,
  `checkin` varchar(50) default NULL,
  PRIMARY KEY  (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERS`
--

LOCK TABLES `USERS` WRITE;
/*!40000 ALTER TABLE `USERS` DISABLE KEYS */;
INSERT INTO `USERS` (`email`, `password`, `fname`, `lname`, `bMonth`, `bDay`, `bYear`, `HomeState`, `HomeCity`, `Movies1`, `Movies2`, `Movies3`, `Music1`, `Music2`, `Music3`, `Sports1`, `Sports2`, `Sports3`, `Major`, `MajorSchool`, `Hobbies1`, `Hobbies2`, `Hobbies3`, `Book1`, `Book2`, `Book3`, `gender`, `pic_url`, `checkin`) VALUES ('jperlin18@gmail.com','test123','Jonathan','Perlin','April',10,1991,'Illinois','Skokie','Action/Adventure','Comedy','Drama','Oldies','80\'s/90\'s','Rock','Baseball','Basketball','Football','Engineering Physics','Engineering','Sports','Friends','Clubs/Organizations','Action/Adventure','Thriller','Comedy','M',NULL,'Siebel Center for Computer Science, North Goodwin '),('test@gmail.com','password','jeff','sucks','April',17,1992,'Ohio','Cincinatti','Action/Adventure','Thriller','Comedy','Hip-Hop/Rap','Alternative','Rock','Baseball','Football','Tennis','Computer Science','Engineering','Sports','Exercise','Friends','Thriller','','','M',NULL,'Siebel Center for Computer Science, North Goodwin'),('jbailey2010@gmail.com','devinisatool','Jeff','Bailey','April',17,1992,'Ohio','Cincinnati','Action/Adventure','Thriller','Comedy','Hip-Hop/Rap','Alternative','Rock','Baseball','Football','Tennis','Computer Science','Engineering','Sports','Exercise','Friends','Thriller','','','M',NULL,'Siebel Center for Computer Science, North Goodwin'),('deck1@illinois.edu','betterthandevin','Christian','Deck','February',15,1992,'Illinois','Byron','Action/Adventure','Comedy','Sci/Fi Fantasy','80\'s/90\'s','R&B','','Football','','','Computer Science','Engineering','Video Games','TV/Movies','','SciFi/Fantasy','','','M',NULL,'Siebel Center for Computer Science, North Goodwin '),('android@gmail.com','willdestroy','Android','Robot','December',25,1985,'Oregon','Seattle','Romance','','','Oldies','Country','Rock','Basketball','Track/Field','','Computer Science','Engineering','Video Games','TV/Movies','','Romance','','','M',NULL,'The, Moon'),('Mrs.Android@gmail.com','thehumans','Mrs.','Android','January',1,1994,'Oregon','Seattle','Romance','','','Oldies','Country','','Golf','Track/Field','','Computer Science','Engineering','Video Games','TV/Movies','','Romance','','','F',NULL,'The, Moon'),('bhushan1@illinois.edu','password','Devin','Bhushan','January',1,1994,'California','San Francisco','Action/Adventure','Thriller','Scary/Horror','Oldies','80\'s/90\'s','Country','Baseball','Basketball','Football','Computer Science','Engineering','Sports','Exercise','Video Games','Action/Adventure','Thriller','Scary/Horror',NULL,NULL,'Siebel Center for Computer Science, North Goodwin '),('zerlure@gmail.com','Devin Scuks','Bob','Barker','March',2,1985,'California','Studio','Action/Adventure','Thriller','','Oldies','80\'s/90\'s','Country','Baseball','Basketball','Football','Computer Science','Engineering','Sports','Exercise','Video Games','Action/Adventure','Thriller','Scary/Horror',NULL,'images/1333936927.jpg','Siebel Center for Computer Science, North Goodwin '),('perlin1@illinois.edu','abc','devin\'s','mom','January',1,1991,'California','San Francisco','Action/Adventure','Thriller','Scary/Horror','Oldies','80\'s/90\'s','Country','Baseball','Basketball','Football','Computer Science','Engineering','Sports','Exercise','Video Games','Action/Adventure','Thriller','Scary/Horror',NULL,NULL,'Siebel Center for Computer Science, North Goodwin '),('walter18@illinois.edu','password','Alan','Walters','April',6,1992,'Illinois','Wayne','Action/Adventure','Comedy','Drama','Oldies','','','Baseball','','','Actuarial Science','Liberal Arts & Sciences','Sports','Exercise','Friends','Action/Adventure','Comedy','SciFi/Fantasy',NULL,'images/1333940451.jpg','Siebel Center for Computer Science, North Goodwin ');
/*!40000 ALTER TABLE `USERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Who_Is_Going`
--

DROP TABLE IF EXISTS `Who_Is_Going`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Who_Is_Going` (
  `Profile_ID` varchar(20) NOT NULL default '',
  `Event_Admin` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`Profile_ID`,`Event_Admin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Who_Is_Going`
--

LOCK TABLES `Who_Is_Going` WRITE;
/*!40000 ALTER TABLE `Who_Is_Going` DISABLE KEYS */;
/*!40000 ALTER TABLE `Who_Is_Going` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Why_Going_Out`
--

DROP TABLE IF EXISTS `Why_Going_Out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Why_Going_Out` (
  `Goal` varchar(20) default NULL,
  `Who_Interacting_With` varchar(20) default NULL,
  `Profile_Username` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`Profile_Username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Why_Going_Out`
--

LOCK TABLES `Why_Going_Out` WRITE;
/*!40000 ALTER TABLE `Why_Going_Out` DISABLE KEYS */;
/*!40000 ALTER TABLE `Why_Going_Out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ajax_chat_bans`
--

DROP TABLE IF EXISTS `ajax_chat_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ajax_chat_bans` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) collate utf8_bin NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajax_chat_bans`
--

LOCK TABLES `ajax_chat_bans` WRITE;
/*!40000 ALTER TABLE `ajax_chat_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `ajax_chat_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ajax_chat_invitations`
--

DROP TABLE IF EXISTS `ajax_chat_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ajax_chat_invitations` (
  `userID` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajax_chat_invitations`
--

LOCK TABLES `ajax_chat_invitations` WRITE;
/*!40000 ALTER TABLE `ajax_chat_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ajax_chat_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ajax_chat_messages`
--

DROP TABLE IF EXISTS `ajax_chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ajax_chat_messages` (
  `id` int(11) NOT NULL auto_increment,
  `userID` int(11) NOT NULL,
  `userName` varchar(64) collate utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `text` text collate utf8_bin,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajax_chat_messages`
--

LOCK TABLES `ajax_chat_messages` WRITE;
/*!40000 ALTER TABLE `ajax_chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ajax_chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ajax_chat_online`
--

DROP TABLE IF EXISTS `ajax_chat_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ajax_chat_online` (
  `userID` int(11) NOT NULL,
  `userName` varchar(64) collate utf8_bin NOT NULL,
  `userRole` int(1) NOT NULL,
  `channel` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `ip` varbinary(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajax_chat_online`
--

LOCK TABLES `ajax_chat_online` WRITE;
/*!40000 ALTER TABLE `ajax_chat_online` DISABLE KEYS */;
/*!40000 ALTER TABLE `ajax_chat_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people` (
  `id` int(11) NOT NULL auto_increment,
  `filename` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'awkwardt_schema'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-04-09  0:03:02
