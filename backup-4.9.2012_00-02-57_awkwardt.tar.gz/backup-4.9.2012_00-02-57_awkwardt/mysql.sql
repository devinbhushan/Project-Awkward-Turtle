-- cPanel mysql backup
GRANT USAGE ON *.* TO 'awkwardt'@'localhost' IDENTIFIED BY PASSWORD '*BF2F1FBE0F9D87FC8D45E6A3684006C56A3C22A4';
GRANT ALL PRIVILEGES ON `awkwardt\_schema`.* TO 'awkwardt'@'localhost';
GRANT ALL PRIVILEGES ON `awkwardt\_%`.* TO 'awkwardt'@'localhost';
